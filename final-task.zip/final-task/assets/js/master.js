$("#my-button").click(() => {
	$("#my-file").click();
});
