// ------------------------- Start Siadebar ------------------------- //
document.addEventListener('DOMContentLoaded', () => {
    const moreItemsToggle = document.querySelector('.more-items-toggle');
    const lessItemsToggle = document.querySelector('.less-items-toggle');
    const sidebar = document.querySelector('.custom-sidebar');

    if (moreItemsToggle && lessItemsToggle && sidebar) {
        moreItemsToggle.addEventListener('click', () => {
            sidebar.classList.add('show-more');
            moreItemsToggle.parentElement.classList.add('d-none'); // مخفی کردن "موارد بیشتر"
            lessItemsToggle.parentElement.classList.remove('d-none'); // نمایش دادن "بستن موارد"
        });

        lessItemsToggle.addEventListener('click', () => {
            sidebar.classList.remove('show-more');
            lessItemsToggle.parentElement.classList.add('d-none'); // مخفی کردن "بستن موارد"
            moreItemsToggle.parentElement.classList.remove('d-none'); // نمایش دادن "موارد بیشتر"
        });
    }
});
// ------------------------- End Siadebar ------------------------- //

function changeImage(imagePath) {
    document.getElementById('mainImage').src = imagePath;
  }